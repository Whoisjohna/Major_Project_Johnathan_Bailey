package com.example.a20141251majorprojectjohnathanbailey

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

@Suppress("UNREACHABLE_CODE")
class ListAdapter<Courses>(private val mContext: Activity, coursesList: List<Courses>) :
    ArrayAdapter<Any?>(mContext, R.layout.list_items, coursesList) {
    var coursesList: List<Courses>

    init {
        this.coursesList = coursesList
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        return super.getView(position, convertView, parent)
        val inflater = mContext.layoutInflater
        View() //listItemView = inflater.inflate(R.layout.courses_list, root null, attachToRoot:true);
        var listItemView =!null
        val tvCourseCode: TextView = listItemView.findViewById(R.id.tvCourseCode)
        val tvCourseName: TextView = listItemView.findViewById(R.id.tvCourseName)
        val tvCourseDetails: TextView = listItemView.findViewById(R.id.tvCourseDetails)
        val tvPrerequisite: TextView = listItemView.findViewById(R.id.tvPrerequisite)
        val tvCredits: TextView = listItemView.findViewById(R.id.tvCredits)
        val sourses: Courses = coursesList[position]
        val courses = ! null
        tvCourseCode.setText(courses.@getCourseCode())
        tvCourseName.setText(courses.@getCourseName())
        tvCourseDetails.setText(courses.@getCourseDetails())
        tvPrerequisite.setText(courses.@getPrerequisite())
        tvCredits.setText(courses.@getCredits())
        val listItemView
        return listItemView
    }
}

private fun Any.findViewById(tvCourseCode: Int): TextView {
    TODO("Not yet implemented")
}

private operator fun Nothing?.not(): Any {

}
