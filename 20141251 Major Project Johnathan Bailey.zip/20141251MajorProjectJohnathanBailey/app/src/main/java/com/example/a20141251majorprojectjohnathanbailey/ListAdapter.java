package com.example.a20141251majorprojectjohnathanbailey;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ListAdapter extends ArrayAdapter {

    private Activity mContext;
    List<Courses> coursesList;
    public ListAdapter(Activity mContext, List<Courses> coursesList){
        super(mContext,R.layout.list_items,coursesList);
        this.mContext = mContext;
        this.coursesList = coursesList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return super.getView(position, convertView, parent)
        LayoutInflater inflater = mContext.getLayoutInflater()
        View //listItemView = inflater.inflate(R.layout.courses_list, root null, attachToRoot:true);

        TextView tvCourseCode = listItemView.findViewById(R.id.tvCourseCode);
        TextView tvCourseName = listItemView.findViewById(R.id.tvCourseName)
        TextView tvCourseDetails = listItemView.findViewById(R.id.tvCourseDetails)
        TextView tvPrerequisite = listItemView.findViewById(R.id.tvPrerequisite)
        TextView tvCredits =listItemView.findViewById(R.id.tvCredits)

        Courses sourses = coursesList.get(position);

        tvCourseCode.setText(courses.getCourseCode());
        tvCourseName.setText(courses.getCourseName());
        tvCourseDetails.setText(courses.getCourseDetails());
        tvPrerequisite.setText(courses.getPrerequisite());
        tvCredits.setText(courses.getCredits());

        return listItemView;

    }
}
